document.addEventListener('DOMContentLoaded', () => {
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');

    function addMessage(message, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${sender}-message`);
        messageDiv.innerHTML = `<p>${message}</p>`;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function showLoading(text) {
        const loadingDiv = document.createElement('div');
        loadingDiv.classList.add('message', 'bot-message', 'loading-indicator');
        loadingDiv.innerHTML = `<i>${text}</i>`;
        loadingDiv.id = "loading-msg";
        chatMessages.appendChild(loadingDiv);
    }

    function removeLoading() {
        const loadMsg = document.getElementById('loading-msg');
        if (loadMsg) loadMsg.remove();
    }

    function detectarPlataforma(url) {
        if (url.includes("tiktok.com")) return "TikTok";
        if (url.includes("twitter.com") || url.includes("x.com")) return "Twitter";
        if (url.includes("youtube.com") || url.includes("youtu.be")) return "YouTubeVideo";
        return null;
    }

    function sendMessage() {
        const text = userInput.value.trim();
        if (!text) return;

        addMessage(text, 'user');
        userInput.value = '';

        const plataforma = detectarPlataforma(text);

        if (!plataforma) {
            addMessage("Plataforma no soportada.", 'bot');
            return;
        }

        procesarDescarga(plataforma, text);
    }

    async function procesarDescarga(plataforma, urlVideo) {
        showLoading(`Procesando enlace de ${plataforma}...`);
        let apiUrl = "";

        switch (plataforma) {
            case 'TikTok':
                apiUrl = `https://api.delirius.store/download/tiktok?url=${urlVideo}`;
                break;
            case 'Twitter':
                apiUrl = `https://api.delirius.store/download/twitterv2?url=${urlVideo}`;
                break;
            case 'YouTubeVideo':
                apiUrl = `https://api.delirius.store/download/ytmp4?url=${urlVideo}`;
                break;
            default:
                removeLoading();
                addMessage("Plataforma no soportada.", 'bot');
                return;
        }

        try {
            const res = await fetch(apiUrl);
            const json = await res.json();
            removeLoading();

            if (!json.status) {
                addMessage("Error al procesar el enlace.", 'bot');
                return;
            }

            let finalDownloadLink = null;
            let videoTitle = "Contenido";
            let thumbnailUrl = "https://via.placeholder.com/300x200";
            let extension = "mp4";

            if (plataforma === 'TikTok') {
                finalDownloadLink = json.data?.meta?.media?.[0]?.org;
                videoTitle = json.data?.title || videoTitle;
                thumbnailUrl = json.data?.cover || thumbnailUrl;
            } 
            else if (plataforma === 'Twitter') {
                const videos = json.data?.media?.[0]?.videos;
                if (videos) {
                    videos.sort((a, b) => b.bitrate - a.bitrate);
                    finalDownloadLink = videos[0].url;
                }
                videoTitle = json.data?.description || videoTitle;
                thumbnailUrl = json.data?.media?.[0]?.cover || thumbnailUrl;
            } 
            else if (plataforma === 'YouTubeVideo') {
                finalDownloadLink = json.data?.download?.url;
                videoTitle = json.data?.title || videoTitle;
                thumbnailUrl = json.data?.image || thumbnailUrl;
            }

            const safeFileName = videoTitle.replace(/[^a-z0-9]/gi, '_').substring(0, 30) + "." + extension;

            if (finalDownloadLink) {
                const cardHtml = `
                    <div class="video-download-card">
                        <p>${videoTitle}</p>
                        <img src="${thumbnailUrl}" width="300">
                        <br>
                        <a href="${finalDownloadLink}" download="${safeFileName}" target="_blank">
                            DESCARGAR
                        </a>
                    </div>
                `;
                addMessage(cardHtml, 'bot');
            } else {
                addMessage("No se pudo obtener el link.", 'bot');
            }

        } catch (error) {
            removeLoading();
            console.error(error);
            addMessage("Error en la descarga.", 'bot');
        }
    }

    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });
});